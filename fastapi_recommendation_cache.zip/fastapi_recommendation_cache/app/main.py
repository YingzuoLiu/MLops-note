from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
import redis
import time
import logging

app = FastAPI()
r = redis.Redis(host="localhost", port=6379, decode_responses=True)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("recommendation")

# 模拟模型服务：根据 user_id 返回推荐结果
def fetch_recommendation_from_model(user_id: str):
    time.sleep(0.2)  # 模拟模型延迟
    return ["item1", "item2", "item3"]

# GET 请求：获取用户推荐结果，缓存优先
@app.get("/recommend/{user_id}")
def recommend(user_id: str):
    cache_key = f"recommend:{user_id}"
    cached = r.get(cache_key)

    if cached:
        logger.info(f"Cache hit for {user_id}")
        return {"user_id": user_id, "items": eval(cached), "source": "cache"}

    try:
        items = fetch_recommendation_from_model(user_id)
        ttl = 60 + hash(user_id) % 30  # 设置随机过期时间，防止缓存雪崩
        r.setex(cache_key, ttl, str(items))  # 写入 Redis 缓存
        logger.info(f"Cache miss for {user_id} - storing in Redis for {ttl}s")
        return {"user_id": user_id, "items": items, "source": "model"}
    except Exception as e:
        logger.error(f"Recommendation failed: {str(e)}")
        raise HTTPException(status_code=500, detail="Recommendation failed")

# DELETE 请求：删除某个用户的推荐缓存
@app.delete("/recommend/{user_id}")
def delete_cache(user_id: str):
    cache_key = f"recommend:{user_id}"
    deleted = r.delete(cache_key)
    if deleted:
        logger.info(f"Cache deleted for {user_id}")
    return {"user_id": user_id, "cache_deleted": bool(deleted)}

# 健康检查接口：检查 Redis 是否正常工作
@app.get("/health")
def health_check():
    try:
        if r.ping():
            return {"status": "healthy"}
        else:
            return {"status": "redis unreachable"}
    except Exception:
        return {"status": "unhealthy"}

# 查看指定用户推荐缓存的 TTL（剩余存活时间）
@app.get("/cache/ttl/{user_id}")
def get_ttl(user_id: str):
    cache_key = f"recommend:{user_id}"
    ttl = r.ttl(cache_key)
    return {"user_id": user_id, "ttl": ttl}