from fastapi import FastAPI, HTTPException
import redis
import time
import random

app = FastAPI()
r = redis.Redis(host='localhost', port=6379, decode_responses=True)


# 模拟推荐结果
def recommend_items(user_id):
    time.sleep(0.1)
    return [f"item_{random.randint(1, 100)}" for _ in range(5)]


# 1. 缓存推荐结果，缓存优先策略
@app.get("/recommend/{user_id}")
def get_recommendation(user_id: str):
    cache_key = f"recommend:{user_id}"
    result = r.get(cache_key)
    if result:
        return {"user_id": user_id, "items": eval(result), "source": "cache"}

    items = recommend_items(user_id)
    r.setex(cache_key, 60, str(items))
    return {"user_id": user_id, "items": items, "source": "model"}


# 2. 记录用户点击行为
@app.post("/click/{user_id}/{item_id}")
def record_click(user_id: str, item_id: str):
    r.lpush(f"click:{user_id}", item_id)
    r.ltrim(f"click:{user_id}", 0, 9)  # 最多保留10条
    return {"msg": f"click {item_id} recorded for user {user_id}"}


# 3. 热度统计（每点击一次热度加1）
@app.post("/hot/{item_id}")
def update_hot(item_id: str):
    r.zincrby("hot_items", 1, item_id)
    return {"msg": f"item {item_id} heat increased"}


# 4. 获取 Top-K 热门商品
@app.get("/hot/topk")
def get_top_hot(k: int = 5):
    top_items = r.zrevrange("hot_items", 0, k-1, withscores=True)
    return {"top_items": top_items}


# 5. 存储用户画像（在线特征）
@app.post("/profile/{user_id}")
def update_profile(user_id: str, gender: str, age: int, genre: str):
    r.hset(f"profile:{user_id}", mapping={"gender": gender, "age": age, "genre": genre})
    return {"msg": f"profile updated for user {user_id}"}


# 6. 获取用户画像
@app.get("/profile/{user_id}")
def get_profile(user_id: str):
    profile = r.hgetall(f"profile:{user_id}")
    if not profile:
        raise HTTPException(status_code=404, detail="profile not found")
    return profile


# 7. 简单限流（每秒只能访问一次）
@app.get("/limited/{user_id}")
def rate_limited(user_id: str):
    key = f"rate:{user_id}"
    if r.exists(key):
        raise HTTPException(status_code=429, detail="Too many requests")
    r.setex(key, 1, 1)
    return {"msg": f"user {user_id} passed rate limit"}