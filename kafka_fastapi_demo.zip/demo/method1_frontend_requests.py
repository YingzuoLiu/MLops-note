
import requests
import random
import time

# Simulate 10 user requests from frontend
for _ in range(10):
    user_id = random.randint(1000, 9999)  # Simulate logged-in user
    url = f"http://localhost:8000/recommend/{user_id}"
    response = requests.get(url)
    print(f"User {user_id} requested: {response.json()}")
    time.sleep(0.5)  # Simulate slight delay between requests
