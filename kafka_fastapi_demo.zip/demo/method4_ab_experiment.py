
from kafka import KafkaProducer
import json
import random

# Kafka setup
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Simulate experiment groups
experiment_groups = ['A', 'B']

for _ in range(10):
    user_id = random.randint(1000, 9999)
    group = random.choice(experiment_groups)

    # Simulate experiment targeting: only group B triggers recommendation
    if group == 'B':
        producer.send("rec_topic", {"user_id": user_id})
        print(f"User {user_id} (Group B) triggered recommendation")
    else:
        print(f"User {user_id} (Group A) skipped (control group)")
