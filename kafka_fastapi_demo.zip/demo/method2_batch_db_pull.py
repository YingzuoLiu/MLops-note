
from kafka import KafkaProducer
import json
import random

# Simulate database pulling active users
user_ids = [random.randint(1000, 9999) for _ in range(10)]

# Setup Kafka producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Send batch user_ids to Kafka
for user_id in user_ids:
    message = {"user_id": user_id}
    producer.send("rec_topic", message)
    print(f"Sent recommendation task for user {user_id}")
producer.flush()
