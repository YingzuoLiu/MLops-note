
from kafka import KafkaProducer
import json
import random
import time

# Setup Kafka producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Simulate continuous user behavior logs (clicks/views)
for _ in range(10):
    user_id = random.randint(1000, 9999)
    action = random.choice(['click', 'view', 'scroll'])
    event = {
        "user_id": user_id,
        "event_type": action,
        "timestamp": time.time()
    }

    # In real systems, this might go to a separate topic like "user_behavior"
    # But we simulate pushing to rec_topic for triggering recommendation
    producer.send("rec_topic", {"user_id": user_id})
    print(f"User {user_id} triggered rec due to {action}")
    time.sleep(0.5)
