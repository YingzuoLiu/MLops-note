
import requests
import time

# Simulate user sending a recommendation request
user_id = 123

print(f"Sending recommendation request for user {user_id}...")
response = requests.get(f"http://localhost:8000/recommend/{user_id}")
print("Response:", response.json())

# Wait a few seconds for worker to process
time.sleep(5)

# Send again to test cache hit
print(f"Requesting again for user {user_id}...")
response = requests.get(f"http://localhost:8000/recommend/{user_id}")
print("Response:", response.json())
