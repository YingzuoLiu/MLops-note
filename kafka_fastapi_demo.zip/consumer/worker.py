
from kafka import KafkaConsumer
import redis
import json
import time

# Kafka Consumer setup
consumer = KafkaConsumer(
    'rec_topic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    group_id='rec-group',
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)

# Redis setup
r = redis.Redis(host='localhost', port=6379, db=0)

for msg in consumer:
    data = msg.value
    user_id = data['user_id']

    # Simulate recommendation logic
    rec_result = [f"item_{i}" for i in range(3)]
    r.set(f"user:{user_id}:rec", json.dumps(rec_result), ex=300)
    print(f"Processed recommendation for user {user_id}: {rec_result}")
