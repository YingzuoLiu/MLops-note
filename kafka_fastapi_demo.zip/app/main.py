
from fastapi import FastAPI
from kafka import KafkaProducer
import redis
import json
import time

app = FastAPI()

# Kafka Producer setup
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Redis setup
r = redis.Redis(host='localhost', port=6379, db=0)

@app.get("/recommend/{user_id}")
def get_recommendation(user_id: int):
    cache_key = f"user:{user_id}:rec"
    cached = r.get(cache_key)
    if cached:
        return {"result": json.loads(cached)}
    
    # Push to Kafka for async processing
    message = {"user_id": user_id, "timestamp": time.time()}
    producer.send("rec_topic", message)
    producer.flush()

    return {"result": "Recommendation is being generated. Please try again later."}
