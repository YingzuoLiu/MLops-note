
import os
import time
import json
import random
import numpy as np
from datetime import datetime
from typing import List, Dict, Any, Optional

from fastapi import FastAPI, Query
from prometheus_client import Counter, Summary, Gauge, generate_latest, CONTENT_TYPE_LATEST
from starlette.responses import Response
from kafka import KafkaProducer
import redis

# ---- Config ----
KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "user_events")

# ---- Prometheus metrics ----
REQUEST_COUNT = Counter("recommend_requests_total", "Total recommendation requests")
REQUEST_LATENCY = Summary("recommend_latency_seconds", "Request latency in seconds")
CTR_GAUGE = Gauge("recommend_ctr", "Click Through Rate (rolling)")
ERROR_COUNT = Counter("recommend_errors_total", "Total errors in recommendation endpoint")

# Rolling counters to compute CTR
_impressions = 0
_clicks = 0

# ---- Kafka Producer ----
def create_producer():
    # linger_ms for batching, retries for resilience
    return KafkaProducer(
        bootstrap_servers=KAFKA_BOOTSTRAP.split(","),
        value_serializer=lambda v: json.dumps(v).encode("utf-8"),
        retries=5,
        linger_ms=10,
        acks="all",
    )

producer = None

# ---- Simple in-memory catalog & user profiles ----
CATEGORIES = ["movie_action", "movie_romance", "movie_comedy", "movie_scifi", "movie_drama"]
CATALOG = [{"item_id": f"i{idx}", "category": random.choice(CATEGORIES)} for idx in range(1, 301)]

# User profile store: user_id -> preferred categories (simulate)
USER_PROFILES: Dict[str, Dict[str, Any]] = {}

# Optional Redis connection for heat lookup
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
_redis = None
def get_redis():
    global _redis
    if _redis is None:
        try:
            _redis = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
        except Exception:
            _redis = None
    return _redis

def get_item_heat(item_id: str) -> float:
    r = get_redis()
    if not r:
        return 0.0
    v = r.get(f"item:heat:{item_id}")
    return float(v) if v is not None else 0.0

def get_or_create_user_profile(user_id: str) -> Dict[str, Any]:
    if user_id not in USER_PROFILES:
        # each user has 1-2 preferred categories
        prefs = random.sample(CATEGORIES, k=random.choice([1, 2]))
        USER_PROFILES[user_id] = {
            "user_id": user_id,
            "preferred_categories": prefs,
            "created_at": datetime.utcnow().isoformat()
        }
    return USER_PROFILES[user_id]

def recommend_items_for_user(user_id: str, k: int = 10) -> List[Dict[str, Any]]:
    profile = get_or_create_user_profile(user_id)
    prefs = set(profile["preferred_categories"])
    # Bias selection towards preferred categories
    preferred = [x for x in CATALOG if x["category"] in prefs]
    others = [x for x in CATALOG if x["category"] not in prefs]
    # Pick 70% from preferred, 30% from others
    k_pref = max(1, int(k * 0.7))
    k_oth = max(0, k - k_pref)
    recs = random.sample(preferred, k=min(k_pref, len(preferred))) + random.sample(others, k=min(k_oth, len(others)))
    random.shuffle(recs)
    # --- Rerank by heat (blend heat with small weight)
    recs = sorted(recs[:k], key=lambda x: get_item_heat(x['item_id']), reverse=True)
    return recs

def simulate_click(user_id: str, recs: List[Dict[str, Any]]) -> Optional[str]:
    # Return clicked item_id or None. Users more likely click from preferred categories.
    profile = get_or_create_user_profile(user_id)
    prefs = set(profile["preferred_categories"])
    # Assign higher click prob to preferred category items
    clicked = None
    for item in recs:
        base = 0.03  # baseline click prob
        if item["category"] in prefs:
            p = base + 0.12  # preferred boost
        else:
            p = base
        if random.random() < p:
            clicked = item["item_id"]
            break
    return clicked

app = FastAPI(title="Recommendation Service Demo", version="0.1.0")

@app.on_event("startup")
def on_startup():
    global producer
    producer = create_producer()

@app.get("/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

@app.get("/profile")
def profile(user_id: str = Query(..., description="User ID")):
    # Return the simulated user profile for inspection.
    return get_or_create_user_profile(user_id)

@REQUEST_LATENCY.time()
@app.get("/recommend")
def recommend(user_id: str = Query(..., description="User ID"), k: int = 10):
    global _impressions, _clicks, producer
    REQUEST_COUNT.inc()
    t0 = time.time()
    try:
        recs = recommend_items_for_user(user_id, k=k)
        clicked_item = simulate_click(user_id, recs)

        # Update rolling CTR
        _impressions += 1
        if clicked_item is not None:
            _clicks += 1
        ctr = (_clicks / _impressions) if _impressions > 0 else 0.0
        CTR_GAUGE.set(ctr)

        # Produce event to Kafka
        event = {
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "recommended_items": [x["item_id"] for x in recs],
            "clicked_item": clicked_item,
        }
        if producer is not None:
            producer.send(KAFKA_TOPIC, value=event)
        else:
            producer = create_producer()
            producer.send(KAFKA_TOPIC, value=event)

        return {"user_id": user_id, "ctr": ctr, "recommended": recs, "clicked_item": clicked_item, "elapsed_ms": int((time.time()-t0)*1000)}
    except Exception as e:
        ERROR_COUNT.inc()
        return {"error": str(e)}
