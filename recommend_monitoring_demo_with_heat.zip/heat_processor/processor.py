
import os
import json
import time
import math
from kafka import KafkaConsumer
import redis

KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "user_events")
REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
ALPHA = float(os.getenv("HEAT_EWMA_ALPHA", "0.2"))  # EWMA smoothing
ZSET_KEY = os.getenv("HEAT_ZSET_KEY", "item:heat:zset")

def main():
    r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, decode_responses=True)
    consumer = KafkaConsumer(
        KAFKA_TOPIC,
        bootstrap_servers=KAFKA_BOOTSTRAP.split(","),
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        enable_auto_commit=True,
        group_id="redis_heat_updater",
        auto_offset_reset="earliest",
        consumer_timeout_ms=10000
    )
    print("[heat_processor] started.")
    for msg in consumer:
        event = msg.value
        clicked = event.get("clicked_item")
        recs = event.get("recommended_items", [])
        # basic rule: reward clicked item (+1), small decay to non-clicked items (-0.05)
        if clicked:
            # EWMA update
            old = r.get(f"item:heat:{clicked}")
            old = float(old) if old is not None else 0.0
            new = (1-ALPHA)*old + ALPHA*1.0
            r.set(f"item:heat:{clicked}", new)
            r.zadd(ZSET_KEY, {clicked: new})
        # apply small decay to recommended items
        for it in recs:
            if it == clicked:
                continue
            old = r.get(f"item:heat:{it}")
            old = float(old) if old is not None else 0.0
            new = (1-ALPHA)*old + ALPHA*(-0.05)
            r.set(f"item:heat:{it}", new)
            r.zadd(ZSET_KEY, {it: new})
    print("[heat_processor] stopped.")

if __name__ == "__main__":
    main()
