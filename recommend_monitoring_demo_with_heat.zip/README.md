# Recommendation Monitoring Demo (End-to-End)

一键启动的最小化推荐系统观测性与数据链路 Demo：**FastAPI 推荐服务 + Kafka 日志 + ClickHouse 存储 + Prometheus 监控 + Grafana 面板 + Alert 告警**。

## 📦 架构

- `FastAPI`：提供 `/recommend` 接口；生成**用户画像**（偏好类目），基于画像**偏置推荐**，并**模拟点击**；发送日志到 Kafka；暴露 Prometheus 指标（QPS、延迟、CTR）。
- `Kafka`：日志中转（topic=`user_events`）。
- `ClickHouse`：Kafka 消费者将日志批量写入 `recommend_logs` 表。
- `Prometheus + Grafana`：监控与可视化；包含 CTR、QPS、平均延迟图。
- `Alertmanager`：当 `recommend_ctr < 0.05` 持续 1 分钟触发告警；Demo 中通过 `alert-logger` 打印到控制台。

## 🚀 快速开始

> 需要安装：Docker、Docker Compose

```bash
docker-compose up --build
```

启动后访问：

- FastAPI: http://localhost:8000/docs
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3000  （账号: admin / 密码: admin）
- ClickHouse HTTP: http://localhost:8123
- Alertmanager: http://localhost:9093

## 🔁 试跑

1. 调用多次推荐接口（可以换 `user_id` 观察不同画像）：
   ```bash
   curl 'http://localhost:8000/recommend?user_id=u123&k=10'
   ```

2. 查看 ClickHouse 是否有落库：
   ```bash
   docker exec -it $(docker ps -qf "ancestor=clickhouse/clickhouse-server:24.2") bash -lc "clickhouse-client --query 'SELECT count() FROM recommend_logs'"
   ```

3. 打开 Grafana → Dashboards → 导入的 `Recommendation Monitoring` 看板。

4. 观察 CTR 告警：若模拟点击率较低（受随机性影响），Prometheus 会推送到 Alertmanager，`alert-logger` 容器会打印收到的告警。

## 🧠 用户画像与点击模拟

- 用户第一次访问会自动生成画像（1~2 个偏好类目）。
- 推荐列表 70% 倾向偏好类目，30% 其他类目。
- 点击概率：偏好类目显著更高（可在 `fastapi_app/app.py` 中调整）。

## 🗃 ClickHouse 表结构

```sql
CREATE TABLE IF NOT EXISTS recommend_logs (
  ts DateTime,
  user_id String,
  recommended_items Array(String),
  clicked_item Nullable(String)
) ENGINE = MergeTree()
ORDER BY (ts, user_id);
```

## ⚠️ 常见问题

- **Grafana 没有数据？** 请先调用 `/recommend` 让 Prometheus 有指标。
- **无法抓取 metrics？** 确认 Prometheus job `recommend-app` 目标 `app:8000` 正常。
- **ClickHouse 无数据？** 查看 `sink` 容器日志，确认 Kafka、ClickHouse 连通。
- **CTR 告警不触发？** Demo 使用随机模拟，尝试多用户多次请求，或降低阈值。

## 🧩 自定义扩展

- 接入 Flink 进行实时 CTR 计算和召回热度更新。
- 在 Kafka 增加 `model_monitor`、`feature_monitor` 主题，观测模型健康度。
- 启用外部通知（钉钉/Slack/Webhook）替换 `alert-logger`。

---

Enjoy!
