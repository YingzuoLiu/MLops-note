from fastapi import FastAPI, Request

app = FastAPI()

@app.post("/")
async def receive_alert(req: Request):
    payload = await req.json()
    print("[ALERT] Received:", payload)
    return {"status": "ok"}
