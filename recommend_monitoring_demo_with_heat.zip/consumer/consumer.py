
import os
import json
import time
from kafka import KafkaConsumer
from clickhouse_driver import Client

KAFKA_BOOTSTRAP = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
KAFKA_TOPIC = os.getenv("KAFKA_TOPIC", "user_events")
CLICKHOUSE_HOST = os.getenv("CLICKHOUSE_HOST", "clickhouse")
CLICKHOUSE_PORT = int(os.getenv("CLICKHOUSE_PORT", "9000"))

def ensure_table(client: Client):
    client.execute('''
    CREATE TABLE IF NOT EXISTS recommend_logs (
        ts DateTime,
        user_id String,
        recommended_items Array(String),
        clicked_item Nullable(String)
    ) ENGINE = MergeTree()
    ORDER BY (ts, user_id)
    ''')

def main():
    # Connect ClickHouse
    client = Client(host=CLICKHOUSE_HOST, port=CLICKHOUSE_PORT)
    ensure_table(client)

    # Kafka consumer
    consumer = KafkaConsumer(
        KAFKA_TOPIC,
        bootstrap_servers=KAFKA_BOOTSTRAP.split(","),
        value_deserializer=lambda v: json.loads(v.decode("utf-8")),
        enable_auto_commit=True,
        group_id="clickhouse_sink",
        auto_offset_reset="earliest",
        consumer_timeout_ms=10000
    )

    print("[consumer] started. waiting for messages...")
    batch = []
    last_flush = time.time()

    for msg in consumer:
        event = msg.value
        ts = event.get("timestamp")
        user_id = event.get("user_id")
        recs = event.get("recommended_items", [])
        clicked = event.get("clicked_item")
        batch.append((ts, user_id, recs, clicked))

        # Flush conditions
        if len(batch) >= 100 or (time.time() - last_flush) > 5:
            client.execute("INSERT INTO recommend_logs (ts, user_id, recommended_items, clicked_item) VALUES", batch)
            print(f"[consumer] flushed {len(batch)} rows to ClickHouse")
            batch = []
            last_flush = time.time()

if __name__ == "__main__":
    main()
