# This is a placeholder PyFlink job showing how you would wire Kafka -> compute -> Redis.
# It is NOT wired into docker-compose to keep the demo lightweight.
# If you want a real Flink pipeline, install PyFlink and run on a Flink cluster.
#
# from pyflink.datastream import StreamExecutionEnvironment
# from pyflink.common.serialization import SimpleStringSchema
# from pyflink.datastream.connectors.kafka import FlinkKafkaConsumer
#
# env = StreamExecutionEnvironment.get_execution_environment()
# consumer = FlinkKafkaConsumer(
#     topics='user_events',
#     deserialization_schema=SimpleStringSchema(),
#     properties={'bootstrap.servers': 'kafka:9092', 'group.id': 'flink'}
# )
# stream = env.add_source(consumer)
# # parse json, compute per-item EWMA, write to Redis (via Python function or custom sink)
# env.execute("redis-heat-updater")
