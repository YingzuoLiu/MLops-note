# Vector Retrieval System

This project demonstrates a production-grade vector retrieval system using FastAPI + FAISS + Redis + NGINX + Kubernetes + Prometheus.

## Modules
- faiss_service: vector search
- nginx: load balancing
- redis: cache
- prometheus + alertmanager: monitoring

## Deployment
```bash
kubectl apply -f kubernetes/
```
