#!/bin/bash
kubectl apply -f kubernetes/
