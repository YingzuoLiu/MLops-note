# FastAPI FAISS 示例
from fastapi import FastAPI
app = FastAPI()

@app.get('/search')
def search():
    return {'result': 'vector result'}
