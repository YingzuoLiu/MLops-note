# Horovod + PyTorch CIFAR-10 Distributed Training

This project demonstrates how to use [Horovod](https://horovod.ai) with PyTorch to train a CNN model on the CIFAR-10 dataset in a distributed manner (multi-GPU, multi-node).

## Requirements
- Python 3.8+
- PyTorch (GPU version recommended)
- torchvision
- horovod (with PyTorch support)

## Installation
```bash
pip install torch torchvision
HOROVOD_WITH_PYTORCH=1 pip install --no-cache-dir horovod[pytorch]
```

## Run
Single machine, 4 GPUs:
```bash
horovodrun -np 4 -H localhost:4 python train_hvd_cifar10.py --epochs 20 --batch-size 128 --fp16
```

Multi-node (2 machines, 4 GPUs each):
```bash
horovodrun -np 8 -H host1:4,host2:4 python train_hvd_cifar10.py --epochs 20 --batch-size 128 --fp16
```

## Features
- Distributed training with Horovod
- Automatic learning rate scaling
- Linear warmup + cosine annealing
- DistributedSampler for dataset
- Rank0 logging and checkpoint saving
- AMP mixed precision
- Optional gradient compression
