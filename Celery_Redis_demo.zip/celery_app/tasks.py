
from celery import Celery
import redis
import json
import time
import random

app = Celery(
    "rec_tasks",
    broker="redis://localhost:6379/1",
    backend="redis://localhost:6379/2",
)

r = redis.Redis(host="localhost", port=6379, db=0)

@app.task(bind=True, autoretry_for=(Exception,), retry_backoff=True, max_retries=3)
def generate_rec(self, user_id: int):
    time.sleep(1.0 + random.random())
    rec = [f"item_{i}" for i in range(5)]
    r.set(f"user:{user_id}:rec", json.dumps(rec), ex=300)
    return {"user_id": user_id, "rec": rec}
