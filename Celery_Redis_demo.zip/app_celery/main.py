
from fastapi import FastAPI
import redis
import json
import time

from celery_app.tasks import generate_rec

app = FastAPI(title="Celery + Redis Async Recommender")

r = redis.Redis(host='localhost', port=6379, db=0)

@app.get("/recommend/{user_id}")
def recommend(user_id: int):
    key = f"user:{user_id}:rec"
    cached = r.get(key)
    if cached:
        return {"result": json.loads(cached), "source": "cache"}

    generate_rec.delay(user_id)
    return {"result": "Generating via Celery, please retry shortly.", "source": "celery-queued"}

@app.get("/recommend_sync/{user_id}")
def recommend_sync(user_id: int):
    key = f"user:{user_id}:rec"
    cached = r.get(key)
    if cached:
        return {"result": json.loads(cached), "source": "cache"}

    task = generate_rec.delay(user_id)
    for _ in range(20):
        time.sleep(0.3)
        cached = r.get(key)
        if cached:
            return {"result": json.loads(cached), "source": "celery-ready"}
    return {"result": "Still generating, please check later.", "source": "timeout"}
