
# Celery + Redis Async Variant

## Prerequisites
- Redis running on localhost:6379

## Install
```bash
pip install -r requirements.txt
```

## Start Celery worker
```bash
celery -A celery_app.tasks worker --loglevel=INFO -Q celery
```

## Start FastAPI (Celery variant)
```bash
uvicorn app_celery.main:app --reload --port 8001
```

## Test
```bash
python demo/celery_client.py
```
