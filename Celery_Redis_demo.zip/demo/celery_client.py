
import requests
import time
import random

user_id = random.randint(1000, 9999)
print(f"Calling Celery async recommend for user {user_id}...")
print(requests.get(f"http://localhost:8001/recommend/{user_id}").json())

print("Waiting for Celery worker to compute...")
time.sleep(2.0)

print("Fetching again (should hit cache):")
print(requests.get(f"http://localhost:8001/recommend/{user_id}").json())
