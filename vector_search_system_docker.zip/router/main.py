from fastapi import FastAPI
from pydantic import BaseModel
import requests
import numpy as np

# 节点地址
NODES = [
    "http://localhost:8001/search",
    "http://localhost:8002/search"
]

app = FastAPI()

class Query(BaseModel):
    vector: list

@app.post("/search")
def search(query: Query):
    all_results = []

    # 并行请求各个节点
    for node_url in NODES:
        try:
            r = requests.post(node_url, json={"vector": query.vector})
            res = r.json()
            for idx, dist in zip(res["indices"], res["distances"]):
                all_results.append((idx, dist))
        except Exception as e:
            print(f"Node {node_url} failed: {e}")

    # 排序 + 取最小的 top-5
    top_results = sorted(all_results, key=lambda x: x[1])[:5]
    return {"top_k": top_results}