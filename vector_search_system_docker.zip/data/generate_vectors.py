import numpy as np
vectors = np.random.rand(100, 128).astype('float32')
np.save('data/items_node1.npy', vectors[:50])
np.save('data/items_node2.npy', vectors[50:])