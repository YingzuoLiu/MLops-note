from fastapi import FastAPI
from pydantic import BaseModel
from vector_index import VectorIndex
import numpy as np

app = FastAPI()
index = VectorIndex()

class Query(BaseModel):
    vector: list

@app.post("/search")
def search(query: Query):
    indices, distances = index.search(np.array(query.vector))
    return {"indices": indices, "distances": distances}