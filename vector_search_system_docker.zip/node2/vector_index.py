import faiss
import numpy as np

class VectorIndex:
    def __init__(self):
        self.vectors = np.load("../data/items_node2.npy").astype("float32")
        self.index = faiss.IndexFlatL2(self.vectors.shape[1])
        self.index.add(self.vectors)

    def search(self, query_vector, top_k=5):
        query_vector = np.array([query_vector], dtype="float32")
        distances, indices = self.index.search(query_vector, top_k)
        return indices[0].tolist(), distances[0].tolist()